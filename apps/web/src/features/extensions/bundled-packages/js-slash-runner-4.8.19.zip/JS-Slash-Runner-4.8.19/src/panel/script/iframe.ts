import { cleanup_protector_url, parent_jquery_url, predefine_url } from '@/iframe/script_url';
import third_party from '@/iframe/third_party_script.html?raw';

// 由于 vue 内使用 `</script>` 存在 bug, 不得不分开写
export function createSrcContent(content: string, use_blob_url: boolean, use_cleanup_protector: boolean) {
  return `<!DOCTYPE html>
<html>
<head>
${use_blob_url ? `<base href="${window.location.origin}"/>` : ''}
${third_party}
<script src="${parent_jquery_url}"></script>
<script src="${predefine_url}"></script>
${use_cleanup_protector && !content.includes('pagehide') ? `<script src="${cleanup_protector_url}"></script>` : ''}
<script src="https://testingcf.jsdelivr.net/gh/N0VI028/JS-Slash-Runner/src/iframe/node_modules/log.js"></script>
</head>
<body>
<script type="module">
${content.match(/^\s*```[^\n]*\n(.*)\n```\s*$/is)?.[1] ?? content}
</script>
</body>
</html>
`;
}
